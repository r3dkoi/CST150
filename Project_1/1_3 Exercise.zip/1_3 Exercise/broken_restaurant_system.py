'''
BROKEN RESTAURANT MANAGEMENT SYSTEM
-----------------------------------
This Flask application is intentionally broken with various bugs for students to fix.
Bugs include:
- Route inconsistencies
- Logic errors in calculations
- Missing functionality
- Incorrect data handling
- Template rendering issues
'''

from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
from datetime import datetime

app = Flask(__name__)
# Uncommented so the secret key so Flask can sign the session cookie. Without this key, Flask can't trust it and will not use it.
app.secret_key = 'restaurant_secret_key' 

# Global variables to store data (instead of a database)
MENU_FILE = 'menu.json'
ORDERS_FILE = 'orders.json'

# Initialize data storage
def initialize_data():
    # Bug: This function doesn't check if files exist before loading
    # Bugfix: changed it from a try-except, to a if-else. Using a bare except will catch all errors, even if the file does exist! 
    #So it won't crash with a useful error, it'll just create the fresh default menu, without us knowing if any data is lost.
    if os.path.exists(MENU_FILE):
        with open(MENU_FILE, 'r') as f:
            menu = json.load(f)
    else:
        # Default menu if file doesn't exist
        menu = {
            'appetizers': [
                {'id': 1, 'name': 'Garlic Bread', 'price': 4.99, 'category': 'appetizers'},
                {'id': 2, 'name': 'Soup of the Day', 'price': 5.99, 'category': 'appetizers'}
            ],
            'main_courses': [
                {'id': 3, 'name': 'Spaghetti Bolognese', 'price': 12.99, 'category': 'main_courses'},
                {'id': 4, 'name': 'Grilled Chicken', 'price': 14.99, 'category': 'main_courses'}
            ],
            'desserts': [
                {'id': 5, 'name': 'Chocolate Cake', 'price': 6.99, 'category': 'desserts'},
                {'id': 6, 'name': 'Ice Cream', 'price': 4.99, 'category': 'desserts'}
            ],
            'drinks': [
                {'id': 7, 'name': 'Soda', 'price': 2.99, 'category': 'drinks'},
                {'id': 8, 'name': 'Coffee', 'price': 3.49, 'category': 'drinks'}
            ]
        }

        with open(MENU_FILE, 'w') as f:
            json.dump(menu, f)
    
    if os.path.exists(ORDERS_FILE):
        with open(ORDERS_FILE, 'r') as f:
            orders = json.load(f)
    else:
        # Default empty orders if file doesn't exist
        orders = []
        with open(ORDERS_FILE, 'w') as f:
            json.dump(orders, f)
    
    return menu, orders

# Load initial data
menu, orders = initialize_data()

# Bug: Missing function to save data back to JSON files
# Bugfix: Uncommented so function can be recalled for use throughout the file
def save_data(data_type, data):
    if data_type == 'menu':
        with open(MENU_FILE, 'w') as f:
            json.dump(data, f)
    elif data_type == 'orders':
        with open(ORDERS_FILE, 'w') as f:
            json.dump(data, f)

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Menu routes
@app.route('/menu')
def view_menu():
    # Bug: Doesn't refresh menu data from file
    # Bug fix: Call initialise data function to refresh menu data from file
    menu, orders = initialize_data()
    return render_template('menu.html', menu=menu)

# Bug: This route has a typo in path - should be '/menu/add'
# Bugfix: Fixed typo of menu
@app.route('/menu/add', methods=['GET', 'POST'])
def add_menu_item():
    if request.method == 'POST':
        # Bug: Missing category validation
        # Bugfix:Included if-else validation, where invalid category flashes an error and redirects back to this menu. 
        category = request.form.get('category')
        if category in menu:
            name = request.form.get('name')
            # Bug: No validation for price being a number
            #Bug fix: Inserted try-except error handling in-case user inputs a letters instead of numbers
            #Bug fix: convert it into a float
            try:
                price = float(request.form.get('price'))
            except ValueError as e:
                flash(f'Invalid price, please enter a number only.')
                return redirect(url_for('add_menu_item'))

            # Generate new ID (bug: doesn't check existing IDs)
            # Changed code to find highest existing IDs and add's 1, as previous one would provude duplicate IDs after deletions.
            new_id = max([i['id'] for category in menu for i in menu[category]]) + 1

            # Bug: Incorrectly adds item to menu
            menu[category].append({
                'id': new_id,
                'name': name,
                #Bug: Doesn't convert price to float
                #Bug fix: convert it into a float so during math calculations it doesn't come up as a erorr
                'price': float(price),
                'category': category
            })

            # Bug: Doesn't save updated menu to file
            # Bugfix: Uncommented save_data function from Line 71
            save_data('menu', menu)

            return redirect(url_for('view_menu'))
        else:
            flash('Category not found')
            return redirect(url_for('add_menu_item'))

    return render_template('add_menu_item.html')

@app.route('/menu/edit/<int:item_id>', methods=['GET', 'POST'])
def edit_menu_item(item_id):
    # Find the item
    item = None
    category = None
    
    # Bug: Inefficient search algorithm
    #Bug fix: Adds breaks to outer loop as well so category (as previously) search stops searching despite already finding the ID
    found = False
    for cat in menu:
        for i in menu[cat]:
            if i['id'] == item_id:
                item = i
                category = cat
                found = True
                break
        if found:
            break 
    
    if item is None:
        flash('Item not found')
        return redirect(url_for('view_menu'))
    
    if request.method == 'POST':
        # Bug: Missing validation
        #Bug fix: included try-except value error handling
        item['name'] = request.form.get('name')
        # Bug: Doesn't convert price to float
        #Bug fix: convert it into a float
        try:
            item['price'] = float(request.form.get('price'))
        except ValueError:
            flash('Invalid price, please enter a number only.')
            return redirect(url_for('edit_menu_item', item_id=item_id))
        
        # Bug: Missing save to file
        # Bugfix: Uncommented save_data function from Line 71
        save_data('menu', menu)
        
        return redirect(url_for('view_menu'))
    
    return render_template('edit_menu_item.html', item=item)

# Bug: This route is completely missing
# Bugfix: Uncommented; if user tried to delete a menu item, Flask would throw a BuildError when rendering the delete menu template. Or a 404 if a user types the delete url.
@app.route('/menu/delete/<int:item_id>')
def delete_menu_item(item_id):
    # Find and remove the item
    for cat in menu:
        for i in range(len(menu[cat])):
            if menu[cat][i]['id'] == item_id:
                menu[cat].pop(i)
                save_data('menu', menu)
                return redirect(url_for('view_menu'))
    
    flash('Item not found')
    return redirect(url_for('view_menu'))

# Order routes
@app.route('/orders')
def view_orders():
    # Bug: Doesn't refresh orders data from file
    # Bug fix: Call initialise data function to refresh menu data from file
    menu, orders = initialize_data()
    return render_template('orders.html', orders=orders)

@app.route('/order/new', methods=['GET', 'POST'])
def new_order():
    if request.method == 'POST':
        # Bug: Missing form validation
        # Bugfix: Added validation if table number is left empty
        table_number = request.form.get('table_number')
        if not table_number:
            flash('This table number does not exist. Please input a valid table number.')
            return redirect(url_for('new_order'))
        
        # Create new order
        new_order = {
            'id': len(orders) + 1,
            'table_number': table_number,
            'items': [],
            'status': 'open',
            # Bug: Wrong date format
            # Bugfix: Formatted with correct date template
            'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
            'total': 0
        }
        
        orders.append(new_order)
        # Bug: Doesn't save updated orders to file
        # Bugfix: Uncommented save_data function from Line 71
        save_data('orders', orders)
        
        # Bug: Incorrect redirect
        #Bug fix, replaced it with url_for() instead of string concat. User will now be redirected to the order they just made page.
        return redirect(url_for('view_order', order_id=new_order['id']))
    
    return render_template('new_order.html')

@app.route('/order/<int:order_id>')
def view_order(order_id):
    # Find the order
    order = None
    for o in orders:
        if o['id'] == order_id:
            order = o
            break
    
    if order is None:
        flash('Order not found')
        return redirect(url_for('view_orders'))
    
    return render_template('view_order.html', order=order, menu=menu)

@app.route('/order/<int:order_id>/add_item', methods=['POST'])
def add_item_to_order(order_id):
    # Find the order
    order = None
    for o in orders:
        if o['id'] == order_id:
            order = o
            break
    
    if order is None:
        flash('Order not found')
        return redirect(url_for('view_orders'))
    
     # Bug: Missing checking if order exists
     # Bugfix: Moved it below the item checking validation, so it only triggers once data is found that the order actually exists
    item_id = int(request.form.get('item_id'))
    quantity = int(request.form.get('quantity', 1))
    
    # Find the menu item
    item = None
    for cat in menu:
        for i in menu[cat]:
            if i['id'] == item_id:
                item = i
                break
    
    if item is None:
        flash('Menu item not found')
        return redirect(url_for('view_order', order_id=order_id))
    
    # Add item to order
    # Bug: Doesn't check if item already exists in order to update quantity
    # Bugfix: Added loop that adds the price of a duplicated item to the order 
    for order_item in order['items']:
        if order_item['id'] == item_id:
            order_item['quantity'] += quantity
            subtotal = order_item['price'] *  order_item['quantity']
            order_item['subtotal'] = subtotal
            break
    else: 
        order['items'].append({
            'id': item['id'],
            'name': item['name'],
            'price': item['price'],
            'quantity': quantity,
            # Bug: Incorrect calculation
            #Bug fix: Correct calculation for a fresh new entry order
            'subtotal': item['price'] * quantity
            })
    
    # Bug: Doesn't update order total
    # Bugfix: Uncommented so the total can change instead of remaining 0.
    order['total'] += item['price'] * quantity
    
    # Bug: Doesn't save updated orders to file
    # Bugfix: Uncommented save_data function from Line 71
    save_data('orders', orders)
    
    return redirect(url_for('view_order', order_id=order_id))

@app.route('/order/<int:order_id>/remove_item/<int:item_index>')
def remove_item_from_order(order_id, item_index):
    # Find the order
    order = None
    for o in orders:
        if o['id'] == order_id:
            order = o
            break
    
    if order is None:
        flash('Order not found')
        return redirect(url_for('view_orders'))
    
    # Bug: Doesn't update order total
    # Bugfix: Uncommented so the total can change instead of remaining 0.
    subtotal = order['items'][item_index]['subtotal']
    order['total'] -= subtotal
    
    # Remove item
    # Bug: Incorrect list indexing
    #Bug fix: Used .pop() as of .remove(). .remove() expects integers, not a list value and will come up as ValueError.
    #  while .pop() requires a list value. 
    # Bug: No bounds checking
    #Bug fix: Checks if user tries to remove an item from their order but item isn't actually in their order.
    if 0 <= item_index < len(order['items']):
        order['items'].pop(item_index)
    else:
        flash('Item does not exist.')
        return redirect(url_for('view_order', order_id=order_id))
    
    # Bug: Doesn't save updated orders to file
    # Bugfix: Uncommented save_data function from Line 71
    save_data('orders', orders)
    
    return redirect(url_for('view_order', order_id=order_id))

@app.route('/order/<int:order_id>/close')
def close_order(order_id):
    # Find the order
    order = None
    for o in orders:
        if o['id'] == order_id:
            order = o
            break
    
    if order is None:
        flash('Order not found')
        return redirect(url_for('view_orders'))
    
    # Bug: Doesn't recalculate total before closing
    # Bugfix: Recalculates total before closing order 
    total = 0
    for item in order['items']:
        # Bug: Doesn't check if keys exist
        #Bug fix: Checks if keys exist, and if they don't they return None and doesn't crash program
        total += item.get('price', 0) * item.get('quantity', 0)
    order['total'] = total
    order['status'] = 'closed'
    
    # Bug: Doesn't save updated orders to file
    # Bugfix: Uncommented save_data function from Line 71
    save_data('orders', orders)
    
    return redirect(url_for('view_bill', order_id=order_id))

@app.route('/order/<int:order_id>/bill')
def view_bill(order_id):
    # Find the order
    order = None
    for o in orders:
        if o['id'] == order_id:
            order = o
            break
    
    if order is None:
        flash('Order not found')
        return redirect(url_for('view_orders'))
    
    # Bug: Total calculation is missing or incorrect
    # Calculate total (bug: should be done when adding/removing items)
    #Bug fix: Fixed using .get()
    total = 0
    for item in order['items']:
        # Bug: Doesn't check if keys exist
        #Bug fix: Checks if keys exist, and if they don't they return None and doesn't crash program
        total += item.get('price', 0) * item.get('quantity', 0)
        
    
    # Bug: Doesn't update order total
    # Bugfix: Intentional commented, as total should be added only when adding/removing, not recalculated at bill
    # order['total'] = total
    
    # Bug: Tax calculation is incorrect
    # Bugfix: Tax calculation IS correct but is just missing the grand total that the user can see to pay
    tax = total * 0.1  # 10% tax
    grand_total = total + tax
    
    return render_template('bill.html', order=order, tax=tax, total=total, grand_total=grand_total)

# Run the application
if __name__ == '__main__':
    app.run(debug=True)
